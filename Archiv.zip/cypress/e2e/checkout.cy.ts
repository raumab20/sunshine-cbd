describe("Checkout Process", () => {
    beforeEach(() => {
      cy.visit("/sign-in");
      cy.get('input[name="email"]').should("be.enabled").type("a1@gmail.com");
      cy.get('input[name="password"]').type("a1@gmail.com");
      cy.get('button[type="submit"]').click();
      cy.url().should("not.include", "/sign-in");
    });
  
    it("Adds a product, proceeds to checkout, and verifies order success", () => {
      // Produkt hinzufügen
      cy.visit("/products");
      cy.get("button").contains("Add to Cart").first().click();
      cy.wait(3000);
  
      // Warenkorb prüfen
      cy.visit("/cart");
      cy.get("ul li").should("have.length.greaterThan", 0);
  
      // Zum Checkout navigieren
      cy.get("a").contains("Proceed to Checkout").click();
      cy.url().should("include", "/checkout");
  
      // Bestellung abschließen
      cy.get("button").contains("Place Order").click();
  
      // Redirect zur Erfolgsseite prüfen
      cy.url().should("include", "/order-success");
      cy.contains("h1", "Order Placed Successfully").should("be.visible");
  
      // Gegenprobe: Sicherstellen, dass der Warenkorb nun leer ist
      cy.visit("/cart");
      cy.contains("p", "The cart is empty.").should("be.visible");
    });
  
    it("Ensures checkout fails when cart is empty", () => {
      cy.visit("/cart");
  
      // Prüfen, ob der Warenkorb leer ist
      cy.contains("p", "The cart is empty.").should("be.visible");
  
      // Direkt versuchen, zur Checkout-Seite zu gehen
      cy.visit("/checkout");
  
      // Prüfen, dass die Bestellung nicht möglich ist
      cy.contains("p", "Your cart is empty.").should("be.visible");
      cy.get("button").contains("Place Order").should("not.exist");
    });
  });