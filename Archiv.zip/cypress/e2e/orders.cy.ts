describe("Order History", () => {
    beforeEach(() => {
      cy.visit("/sign-in");
      cy.get('input[name="email"]').should("be.enabled").type("a1@gmail.com");
      cy.get('input[name="password"]').type("a1@gmail.com");
      cy.get('button[type="submit"]').click();
      cy.url().should("not.include", "/sign-in");
    });
  
    it("Checks if order history displays past orders", () => {
      cy.visit("/orders");
  
      // Prüfen, ob mindestens eine Bestellung existiert
      cy.get("ul li").should("have.length.greaterThan", 0);
  
      // Bestellstatus prüfen
      cy.contains("Status").should("exist");
  
      // Produkte innerhalb einer Bestellung prüfen
      cy.get("ul li").first().within(() => {
        cy.get("h2").should("exist"); // Order ID
        cy.get("p").contains("Status").should("exist"); // Status der Bestellung
      });
  
      // Gegenprobe: Keine ungültigen Produkte in der Bestellung
      cy.get("ul li")
        .first()
        .within(() => {
          cy.get("p").contains("Unknown Product").should("not.exist");
        });
    });
  
    it("Ensures order history is empty for a new user", () => {
      // Nutzer mit keiner Bestellung testen
      cy.visit("/sign-in");
      cy.get('input[name="email"]').should("be.enabled").type("newuser@gmail.com");
      cy.get('input[name="password"]').type("newuser@gmail.com");
      cy.get('button[type="submit"]').click();
      cy.url().should("not.include", "/sign-in");
  
      cy.visit("/orders");
  
      // Prüfen, dass keine Bestellungen existieren
      cy.contains("p", "No orders found.").should("be.visible");
      cy.get("ul li").should("not.exist");
    });
  });