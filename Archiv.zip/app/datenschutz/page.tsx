import React from 'react';

import { NextPage } from 'next';

const DatenschutzPage: NextPage = () => {
    return (
        <div>
            <h1 className="text-2xl font-bold text-center">Datenschutzerklärung</h1>
        </div>
    );
};

export default DatenschutzPage;