import React from 'react';

import { NextPage } from 'next';

const AgbsPage: NextPage = () => {
    return (
        <div>
            <h1 className="text-2xl font-bold text-center">Allgemeine Geschäftsbedingungen (AGBs)</h1>
        </div>
    );
};

export default AgbsPage;