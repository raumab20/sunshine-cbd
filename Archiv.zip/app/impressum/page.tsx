import React from 'react';

import { NextPage } from 'next';

const ImpressumPage: NextPage = () => {
    return (
        <div>
            <h1 className="text-2xl font-bold text-center">Impressum</h1>
        </div>
    );
};

export default ImpressumPage;